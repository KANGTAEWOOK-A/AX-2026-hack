'use strict';
const $=q=>document.querySelector(q), $$=q=>[...document.querySelectorAll(q)];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let items=[], active=null, health=null, toastTimer=null;
function toast(msg,bad=false){const el=$('#toast');el.textContent=msg;el.classList.toggle('bad',bad);el.classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('visible'),4200)}
async function api(path, options={}){const r=await fetch(path,options);let j;try{j=await r.json()}catch{j={detail:`HTTP ${r.status}`}}if(!r.ok)throw Error(typeof j.detail==='string'?j.detail:JSON.stringify(j.detail||j));return j}
const tag=p=>({normal:'정상 · 미검출',defect:'결함 감지',unknown:'결과 미해석',pending:'대기'}[p]||p);
const formatPercent=v=>v==null?'평가 불가':`${(v*100).toFixed(1)}%`;
async function refresh(){
  try{
    const [h,s,p]=await Promise.all([api('/api/health'),api('/api/summary'),api('/api/items?limit=400')]);health=h;items=p.items;
    $('#connectionDot').classList.toggle('online',h.aistream_configured);$('#connectionLabel').textContent=h.aistream_configured?'URL 설정됨':'URL 미설정';
    $('#statTotal').textContent=s.total.toLocaleString();$('#statAnalyzed').textContent=s.analyzed.toLocaleString();$('#statNormals').textContent=s.normals.toLocaleString();$('#statReviewed').textContent=s.reviewed.toLocaleString();
    $('#itemsCaption').textContent=`${p.count}개 항목 · 미확인 ${s.unknown}건 · 대기 ${s.pending}건`;
    $('#rankMode').textContent=h.ranker_trained?'오류 예측 모델 학습됨':'규칙 기반 · 학습 전';
    $('#simulationNotice').classList.toggle('hidden',s.simulation===0);
    renderItems();
  }catch(e){toast(e.message,true)}
}
function renderItems(){
  const host=$('#itemList');
  if(!items.length){host.innerHTML='<div class="empty-state">등록된 이미지가 없습니다.<br>대회 제공 풍력 이미지와 라벨을 가져오세요.</div>';return}
  host.innerHTML=items.map(r=>`<div class="item-row" data-id="${r.id}"><img src="${r.image_url}" loading="lazy" alt="검사 이미지"/><div><b title="${esc(r.filename)}">${esc(r.filename)}</b><small>${r.origin==='simulated'?'시뮬레이션 · ':''}${esc(r.session||'촬영 세션 미지정')} · ${r.api_state==='error'?'API 오류':esc(r.review_status)}</small></div><span class="item-tag ${esc(r.pred)}">${esc(tag(r.pred))}</span></div>`).join('');
  $$('#itemList .item-row').forEach(el=>el.addEventListener('click',()=>openModal(el.dataset.id)));
}
async function upload(file){if(!file)return;const fd=new FormData();fd.append('file',file);try{toast('이미지를 등록합니다.');const out=await api('/api/upload',{method:'POST',body:fd});await refresh();await openModal(out.id);toast('이미지 등록 완료. 모델 추론을 실행하세요.')}catch(e){toast(e.message,true)}}
async function importZip(file){if(!file)return;const fd=new FormData();fd.append('file',file);try{toast('ZIP 이미지·정답 파일을 가져오는 중입니다.');const r=await api('/api/import-zip',{method:'POST',body:fd});await refresh();toast(`${r.imported}장 가져오기 완료 · 실패 ${r.total_errors}건${r.total_errors?' / CSV·이미지 연결 확인':''}`)}catch(e){toast(e.message,true)}}
async function inferPending(){if(!health?.aistream_configured){toast('먼저 .env에 AISTREAM_WIND_URL을 설정하고 서버를 재시작하세요.',true);return}
  const target=items.filter(r=>r.api_state!=='success'&&r.origin!=='simulated');if(!target.length){toast('추론 대상이 없습니다.');return}
  if(!confirm(`${target.length}장의 AIStream API 추론을 시작합니다. 계속할까요?`))return;
  $('#inferBtn').disabled=true;let ok=0,errors=0;for(let i=0;i<target.length;i++){
    $('#inferProgress').textContent=`추론 ${i+1}/${target.length}`;
    try{await api(`/api/infer/${target[i].id}`,{method:'POST'});ok++}catch(e){errors++;if(i===0)toast(`첫 추론 오류: ${e.message}`,true)}
    if((i+1)%3===0||i===target.length-1)await refresh();
  }
  $('#inferProgress').textContent='';$('#inferBtn').disabled=false;toast(`추론 완료 ${ok}건 · 오류 ${errors}건`,!!errors)
}
async function generateQueue(){const k=Number($('#budget').value)||5;try{const r=await api(`/api/queue?k=${k}`);$('#queueCaption').textContent=`대상 ${r.eligible}장 / 배정 ${r.k}장 · ${r.simulation_only?'시뮬레이션 전용 (실제 검증 제외)':(r.trained?'오류 순위 모델':'규칙 기반')}`;
 const host=$('#queueList');if(!r.items.length){host.innerHTML='<div class="empty-state compact">AIStream에서 정상·미검출로 해석된 이미지가 없습니다.</div>';return}
 host.innerHTML=r.items.map((x,i)=>`<div class="queue-row" data-id="${x.id}"><span class="queue-rank">${String(i+1).padStart(2,'0')}</span><img src="${x.image_url}" alt="검수 대상"/><div class="row-body"><b>${esc(x.filename)}</b><small>${esc(x.priority_method)} · ${esc(x.review_status)}</small></div><span class="queue-score">${(x.priority*100).toFixed(1)}</span></div>`).join('');
 $$('#queueList .queue-row').forEach(el=>el.addEventListener('click',()=>openModal(el.dataset.id)));
 }catch(e){toast(e.message,true)}}
async function train(){try{const r=await api('/api/train',{method:'POST'});toast(`학습 완료: ${r.train_count}건, 확인된 누락 결함 ${r.missed_defect_count}건`);await refresh()}catch(e){toast(e.message,true)}}
async function evaluate(){try{const k=Number($('#budget').value)||5;const d=await api(`/api/evaluate?k=${k}`);
 if(!d.test_count){$('#evalContent').innerHTML='<div class="empty-state">분리된 TEST 집합에 모델 정상·미검출 결과와 정답이 모두 있는 이미지가 없습니다.</div>';$('#revealWrap').classList.add('hidden');return}
 $('#evalContent').innerHTML=d.methods.map(m=>`<div class="eval-row"><div class="eval-label"><b>${esc(m.method)}</b><span>${formatPercent(m.capture_at_k)} · ${m.found}/${d.missed_defect_count}건 포착</span></div><div class="eval-bar"><div class="eval-fill ${m.method==='Wind Recheck'?'proposed':''}" style="width:${(m.capture_at_k||0)*100}%"></div></div></div>`).join('')+
 `<div class="eval-note">TEST ${d.test_count}장 · 실제 누락 결함 ${d.missed_defect_count}장 · 검수 예산 K=${d.k} · 누락 0건일 때 포착률은 평가 불가<br>${esc(d.warning)}</div>`;
 $('#revealWrap').classList.remove('hidden');$('#revealContent').innerHTML='';
 }catch(e){toast(e.message,true)}}
async function reveal(){try{const k=Number($('#budget').value)||5;const x=await api(`/api/reveal?k=${k}`);$('#revealContent').innerHTML=x.items.map(r=>`<div class="reveal-tile"><img src="${r.image_url}"/><div>${esc(r.filename)}<br><b>실제 ${r.truth==='defect'?'결함':'정상'}</b></div></div>`).join('')||'선택된 평가 이미지가 없습니다.'}catch(e){toast(e.message,true)}}
async function openModal(id){const r=items.find(x=>x.id===id);if(!r)return;active=r;$('#modalTitle').textContent=r.filename;$('#modalImage').src=r.image_url;
 const parts=[`AI 판단: ${tag(r.pred)}`,`검수 상태: ${r.review_status}`,`모델 점수: ${r.confidence==null?'미제공':r.confidence}`,`검수 우선순위: ${r.priority==null?'해당 없음':(r.priority*100).toFixed(1)}`,`선정 근거: ${r.reason||'추론 전'}`];
 $('#modalDetails').innerHTML=parts.map(x=>`<span>${esc(x)}</span>`).join('');$('#reviewNote').value=r.review_note||'';$('#rawResponse').textContent='';$('#modalBackdrop').classList.remove('hidden');
 try{const raw=await api(`/api/response/${r.id}`);if(raw.response)$('#rawResponse').textContent='실제 API 응답(JSON)\n'+JSON.stringify(raw.response,null,2).slice(0,6000)}catch{}
}
async function review(status){if(!active)return;try{await api('/api/review',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:active.id,status,note:$('#reviewNote').value})});$('#modalBackdrop').classList.add('hidden');await refresh();toast(status==='completed'?'검토 기록 저장 완료':'보류 상태 저장 완료')}catch(e){toast(e.message,true)}}
function setup(){
 $$('#importBtn,#uploadBtn,#refreshBtn,#queueBtn,#inferBtn,#trainBtn,#evaluateBtn,#revealBtn,#exportBtn').forEach(x=>{x.addEventListener('click',()=>{
 const f={importBtn:()=>$('#zipInput').click(),uploadBtn:()=>$('#imageInput').click(),refreshBtn:refresh,queueBtn:generateQueue,inferBtn:inferPending,trainBtn:train,evaluateBtn:evaluate,revealBtn:reveal,exportBtn:()=>location.assign('/api/export')};return f[x.id]?.()})});
 $('#imageInput').addEventListener('change',e=>{upload(e.target.files[0]);e.target.value=''});$('#zipInput').addEventListener('change',e=>{importZip(e.target.files[0]);e.target.value=''});
 $('#modalClose').addEventListener('click',()=>$('#modalBackdrop').classList.add('hidden'));$('#modalBackdrop').addEventListener('click',e=>{if(e.target.id==='modalBackdrop')$('#modalBackdrop').classList.add('hidden')});
 $$('[data-review]').forEach(x=>x.addEventListener('click',()=>review(x.dataset.review)));
 $$('.nav-link').forEach(x=>x.addEventListener('click',()=>{$$('.nav-link').forEach(b=>b.classList.remove('active'));x.classList.add('active');$('#'+x.dataset.target).scrollIntoView({behavior:'smooth',block:'start'})}));
 refresh();
}
document.addEventListener('DOMContentLoaded',setup);
