"""Wind Recheck MVP: AI-assisted inspection triage; not a safety certification system."""
import csv
import io
import json
import os
import sqlite3
import time
import uuid
import zipfile
from contextlib import contextmanager
from pathlib import Path

from dotenv import load_dotenv
from fastapi import FastAPI, File, Form, HTTPException, Query, UploadFile
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from PIL import Image, UnidentifiedImageError
from pydantic import BaseModel

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / '.env')
from app.aistream import infer
from app.engine import evaluate, fit_model, image_features, load_model, priority, quality_risk

DATA = Path(os.getenv('WR_DATA_DIR', str(ROOT / 'data')))
UPLOADS = DATA / 'uploads'
UPLOADS.mkdir(parents=True, exist_ok=True)
DB = DATA / 'recheck.sqlite3'
MODEL = DATA / 'ranker.joblib'
MAX_IMAGE_BYTES = 12 * 1024 * 1024
MAX_ZIP_BYTES = 130 * 1024 * 1024
MAX_IMPORT_ITEMS = 300

app = FastAPI(title='Wind Recheck', version='0.1.0')
app.mount('/static', StaticFiles(directory=ROOT / 'app' / 'static'), name='static')


def conn():
    c = sqlite3.connect(DB, timeout=10)
    c.row_factory = sqlite3.Row
    return c


@contextmanager
def db():
    c = conn()
    try:
        yield c
        c.commit()
    finally:
        c.close()


def setup_db():
    with db() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS items (
            id TEXT PRIMARY KEY, filename TEXT NOT NULL, storage_name TEXT NOT NULL,
            uploaded_at REAL NOT NULL, truth TEXT, split TEXT NOT NULL DEFAULT 'unassigned',
            session TEXT, part TEXT, origin TEXT NOT NULL DEFAULT 'real',
            pred TEXT DEFAULT 'pending', confidence REAL, reason TEXT, raw_response TEXT,
            api_state TEXT DEFAULT 'pending', api_latency_ms INTEGER,
            brightness REAL, contrast REAL, blur_log REAL, dark_ratio REAL, bright_ratio REAL,
            review_status TEXT DEFAULT 'pending', review_note TEXT DEFAULT '', reviewed_at REAL
        );
        CREATE INDEX IF NOT EXISTS idx_pred ON items(pred);
        CREATE INDEX IF NOT EXISTS idx_split ON items(split);
        ''')


setup_db()


def rows():
    with db() as c:
        return [dict(x) for x in c.execute('SELECT * FROM items ORDER BY uploaded_at DESC')]


def public_row(r):
    out = {k: v for k, v in r.items() if k not in ('truth', 'storage_name', 'raw_response')}
    out['image_url'] = f"/api/image/{r['id']}"
    out['quality_risk'] = quality_risk(r)
    if r.get('pred') == 'normal':
        value, method = priority(r, load_model(MODEL))
        out['priority'] = value
        out['priority_method'] = method
    else:
        out['priority'] = None
        out['priority_method'] = None
    return out


def validate_save(image_bytes, filename):
    if len(image_bytes) > MAX_IMAGE_BYTES:
        raise ValueError('이미지 크기는 12MB 이하여야 합니다.')
    if not image_bytes:
        raise ValueError('빈 이미지입니다.')
    try:
        with Image.open(io.BytesIO(image_bytes)) as img:
            img.verify()
        with Image.open(io.BytesIO(image_bytes)) as img:
            if img.width * img.height > 95_000_000:
                raise ValueError('이미지 최대 픽셀 수를 초과했습니다.')
            rgb = img.convert('RGB')
            out = io.BytesIO()
            rgb.save(out, format='JPEG', quality=90)
            safe_bytes = out.getvalue()
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError):
        raise ValueError('지원되지 않거나 손상된 이미지입니다.') from None
    item_id = uuid.uuid4().hex
    stored = item_id + '.jpg'
    target = UPLOADS / stored
    target.write_bytes(safe_bytes)
    feature = image_features(target)
    original = Path(str(filename).replace('\\', '/')).name[:120] or 'image.jpg'
    return item_id, original, stored, feature


def insert_image(image_bytes, filename, truth=None, split='unassigned', session='', part='', origin='real'):
    if truth not in (None, 'normal', 'defect'):
        raise ValueError('정답 라벨은 normal 또는 defect이어야 합니다.')
    if split not in ('train', 'val', 'test', 'unassigned'):
        raise ValueError('split은 train/val/test/unassigned 중 하나여야 합니다.')
    item_id, original, stored, feature = validate_save(image_bytes, filename)
    try:
        with db() as c:
            c.execute('''INSERT INTO items
            (id, filename, storage_name, uploaded_at, truth, split, session, part, origin,
             brightness, contrast, blur_log, dark_ratio, bright_ratio)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
            (item_id, original, stored, time.time(), truth, split, str(session)[:100], str(part)[:100],
             origin, feature['brightness'], feature['contrast'], feature['blur_log'],
             feature['dark_ratio'], feature['bright_ratio']))
    except Exception:
        (UPLOADS / stored).unlink(missing_ok=True)
        raise
    return item_id


@app.get('/')
def home():
    return FileResponse(ROOT / 'app' / 'static' / 'index.html')


@app.get('/api/health')
def health():
    return {'ok': True, 'aistream_configured': bool(os.getenv('AISTREAM_WIND_URL')),
            'ranker_trained': MODEL.exists(), 'test_data': sum(r['split'] == 'test' for r in rows()),
            'api_mode': os.getenv('AISTREAM_REQUEST_MODE', 'multipart'),
            'notice': '실제 성능 검증에는 제공 데이터·정답 라벨과 AIStream 실제 응답이 필요합니다.'}


@app.get('/api/summary')
def summary():
    all_rows = rows()
    return {'total': len(all_rows),
            'analyzed': sum(r['pred'] in ('normal', 'defect') for r in all_rows),
            'normals': sum(r['pred'] == 'normal' for r in all_rows),
            'defects': sum(r['pred'] == 'defect' for r in all_rows),
            'unknown': sum(r['pred'] == 'unknown' for r in all_rows),
            'pending': sum(r['api_state'] == 'pending' for r in all_rows),
            'reviewed': sum(r['review_status'] == 'completed' for r in all_rows),
            'simulation': sum(r['origin'] == 'simulated' for r in all_rows)}


@app.get('/api/items')
def list_items(limit: int = Query(default=200, ge=1, le=500), pred: str = '', split: str = ''):
    all_rows = rows()
    if pred: all_rows = [r for r in all_rows if r['pred'] == pred]
    if split: all_rows = [r for r in all_rows if r['split'] == split]
    return {'items': [public_row(r) for r in all_rows[:limit]], 'count': len(all_rows)}


@app.get('/api/image/{item_id}')
def get_image(item_id: str):
    with db() as c:
        row = c.execute('SELECT storage_name FROM items WHERE id=?', (item_id,)).fetchone()
    if row is None: raise HTTPException(404, '이미지를 찾을 수 없습니다.')
    return FileResponse(UPLOADS / row['storage_name'], media_type='image/jpeg', headers={'Cache-Control': 'private, max-age=30'})


@app.post('/api/upload')
async def upload_image(file: UploadFile = File(...)):
    content = await file.read(MAX_IMAGE_BYTES + 1)
    try:
        item_id = insert_image(content, file.filename or 'image.jpg')
    except ValueError as e:
        raise HTTPException(400, str(e)) from None
    return {'ok': True, 'id': item_id, 'message': '이미지 등록 완료. AIStream 추론을 실행하세요.'}


@app.post('/api/import-zip')
async def import_zip(file: UploadFile = File(...)):
    binary = await file.read(MAX_ZIP_BYTES + 1)
    if len(binary) > MAX_ZIP_BYTES:
        raise HTTPException(400, 'ZIP 파일은 130MB 이하여야 합니다. 여러 개로 나눠 업로드하세요.')
    successes, errors = [], []
    try:
        with zipfile.ZipFile(io.BytesIO(binary)) as archive:
            member_names = archive.namelist()
            if any(x.endswith('/') for x in member_names):
                member_names = [x for x in member_names if not x.endswith('/')]
            manifest_name = next((n for n in member_names if Path(n).name.lower() == 'manifest.csv'), None)
            if not manifest_name:
                raise ValueError('ZIP 루트 또는 하위 폴더에 manifest.csv가 필요합니다. README를 참조하세요.')
            if archive.getinfo(manifest_name).file_size > 3_000_000:
                raise ValueError('manifest.csv 크기 제한 3MB')
            csv_text = archive.read(manifest_name).decode('utf-8-sig')
            manifest = list(csv.DictReader(io.StringIO(csv_text)))
            if len(manifest) > MAX_IMPORT_ITEMS:
                raise ValueError(f'한 번에 최대 {MAX_IMPORT_ITEMS}개 이미지만 가져올 수 있습니다.')
            if not manifest or not {'image_file', 'truth'}.issubset(manifest[0]):
                raise ValueError('manifest.csv에 image_file,truth 열이 필요합니다.')
            image_members = {n.replace('\\', '/').lstrip('./'): n for n in member_names}
            for row in manifest:
                filename = (row.get('image_file') or '').replace('\\', '/').lstrip('./')
                if filename not in image_members:
                    errors.append({'filename': filename, 'error': 'ZIP 안에 이미지 없음'}); continue
                info = archive.getinfo(image_members[filename])
                if info.file_size > MAX_IMAGE_BYTES:
                    errors.append({'filename': filename, 'error': '이미지 크기 제한 초과'}); continue
                try:
                    truth = row['truth'].strip().lower()
                    split = (row.get('split') or 'unassigned').strip().lower()
                    item_id = insert_image(archive.read(image_members[filename]), filename, truth=truth,
                                           split=split, session=row.get('session') or '', part=row.get('part') or '')
                    successes.append(item_id)
                except (ValueError, OSError) as e:
                    errors.append({'filename': filename, 'error': str(e)})
    except (ValueError, zipfile.BadZipFile, UnicodeDecodeError, KeyError) as e:
        raise HTTPException(400, str(e)) from None
    return {'imported': len(successes), 'errors': errors[:25], 'total_errors': len(errors)}


@app.post('/api/infer/{item_id}')
def infer_one(item_id: str):
    with db() as c:
        row = c.execute('SELECT * FROM items WHERE id=?', (item_id,)).fetchone()
    if not row:
        raise HTTPException(404, '이미지 없음')
    if row['origin'] == 'simulated':
        raise HTTPException(409, '시뮬레이션 자료는 실제 API 성능 평가에 사용할 수 없습니다.')
    started = time.monotonic()
    try:
        parsed, raw = infer((UPLOADS / row['storage_name']).read_bytes(), row['filename'])
    except ValueError as e:
        with db() as c:
            c.execute('UPDATE items SET api_state=?, reason=? WHERE id=?', ('error', str(e)[:500], item_id))
        raise HTTPException(400, str(e)) from None
    except Exception:
        with db() as c:
            c.execute('UPDATE items SET api_state=?, reason=? WHERE id=?', ('error', 'API 통신 실패', item_id))
        raise HTTPException(502, 'AIStream API 연결 실패. URL·네트워크·요청 형식을 확인하세요.') from None
    elapsed = round((time.monotonic() - started) * 1000)
    with db() as c:
        c.execute('''UPDATE items SET pred=?, confidence=?, reason=?, raw_response=?, api_state=?, api_latency_ms=?
                  WHERE id=?''', (parsed['pred'], parsed['confidence'], parsed['reason'],
                  json.dumps(raw, ensure_ascii=False)[:50000], 'success', elapsed, item_id))
    return {'id': item_id, **parsed, 'api_latency_ms': elapsed}


@app.get('/api/response/{item_id}')
def raw_response(item_id: str):
    with db() as c:
        row = c.execute('SELECT raw_response FROM items WHERE id=?', (item_id,)).fetchone()
    if not row: raise HTTPException(404, '이미지 없음')
    return {'response': json.loads(row['raw_response']) if row['raw_response'] else None}


@app.post('/api/train')
def train_ranker():
    try:
        return {'ok': True, **fit_model(rows(), MODEL)}
    except ValueError as e:
        raise HTTPException(400, str(e)) from None


@app.get('/api/queue')
def queue(k: int = Query(default=10, ge=1, le=200)):
    all_rows = [r for r in rows() if r['pred'] == 'normal' and r['origin'] != 'simulated']
    if not all_rows:
        all_rows = [r for r in rows() if r['pred'] == 'normal' and r['origin'] == 'simulated']
    model = load_model(MODEL)
    ranked = sorted(all_rows, key=lambda r: priority(r, model)[0], reverse=True)
    return {'eligible': len(all_rows), 'k': min(k, len(all_rows)), 'trained': model is not None,
            'simulation_only': bool(all_rows) and all(r['origin'] == 'simulated' for r in all_rows),
            'items': [public_row(r) for r in ranked[:k]]}


class Review(BaseModel):
    id: str
    status: str
    note: str = ''


@app.post('/api/review')
def review_item(body: Review):
    if body.status not in ('pending', 'completed', 'hold'):
        raise HTTPException(400, 'status는 pending/completed/hold 중 하나')
    with db() as c:
        exists = c.execute('SELECT 1 FROM items WHERE id=?', (body.id,)).fetchone()
        if not exists: raise HTTPException(404, '대상 이미지 없음')
        c.execute('UPDATE items SET review_status=?,review_note=?,reviewed_at=? WHERE id=?',
                  (body.status, body.note[:1000], time.time(), body.id))
    return {'ok': True}


@app.get('/api/evaluate')
def get_evaluation(k: int = Query(default=10, ge=1, le=200)):
    return evaluate(rows(), k, load_model(MODEL))


@app.get('/api/reveal')
def reveal(k: int = Query(default=10, ge=1, le=200), method: str = 'Wind Recheck'):
    """Explicit reveal action for evaluation slides; never used for prioritization."""
    all_rows = {r['id']: r for r in rows()}
    trial = evaluate(list(all_rows.values()), k, load_model(MODEL))
    matched = next((m for m in trial['methods'] if m['method'] == method), None)
    if matched is None: raise HTTPException(404, '평가 방법 없음')
    return {'method': method, 'items': [{'id': x, 'filename': all_rows[x]['filename'],
                  'truth': all_rows[x]['truth'], 'image_url': f'/api/image/{x}'} for x in matched['ids']]}


@app.get('/api/export')
def export_records():
    f = io.StringIO()
    names = ['id', 'filename', 'split', 'session', 'part', 'pred', 'confidence', 'api_state',
             'review_status', 'review_note', 'api_latency_ms']
    writer = csv.DictWriter(f, fieldnames=names)
    writer.writeheader()
    for row in rows(): writer.writerow({n: row[n] for n in names})
    f.seek(0)
    return StreamingResponse(iter([f.getvalue().encode('utf-8-sig')]), media_type='text/csv',
                             headers={'Content-Disposition': 'attachment; filename=wind_recheck_records.csv'})
