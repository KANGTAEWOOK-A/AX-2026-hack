# Wind Recheck — 풍력 설비 AI 재검수 우선순위 MVP

제공된 풍력 결함 분석 모델이 **정상/미검출**이라고 판정한 이미지를 다시 볼 우선순위를 계산하고, 제한된 수량(K)에서 실제 누락 결함을 얼마나 포함시키는지 평가하는 웹 서비스입니다.

> **현재 상태:** 실행 가능한 소스코드 제공. 실제 AIStream 호출 및 정량 성능은 사용자의 대회용 `이미지 + 정답 라벨 + 실제 API URL`이 들어와야 검증할 수 있습니다. 실성능·개선률을 생성하거나 주장하지 않습니다. 산업 안전을 보증하는 제품이 아닙니다.

## macOS (Apple Silicon / Intel)

Mac에서는 `Start_Wind_Recheck_Mac.command`를 더블클릭하면 첫 실행 시 가상환경 설치 후 웹 서비스가 자동으로 시작됩니다. Python 3.10~3.13이 필요하며 Python 3.12를 권장합니다. 자세한 내용은 `Mac_Quick_Start.md`를 참조하세요.

**주의:** Mac의 `localhost` 실행은 공개 URL 배포가 아닙니다. 실제 심사를 위해서는 별도의 해커톤 서버에 배포해야 합니다.

## 빠른 시작

```bash
cd wind_recheck_mvp
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# .env에 본인 AIStream 풍력 predict URL 설정 (아래 참조)
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

접속: http://localhost:8000 (또는 서버의 공개 URL). 사용: 업로드 → 추론 실행 → 검수 K 선택 → 검토 → 평가.

AIStream 배포 화면에서 실제 풍력 서빙 URL을 확인한 후 `AISTREAM_WIND_URL`에 **POST /predict/wind 전체 URL**을 넣어야 합니다. 교육자료의 URL은 끝부분만 제공되며 호스트는 이 파일에 없습니다. 첫 번째 사진으로 `/docs`에 표시된 요청 인자 이름을 확인하세요. 기본은 `multipart` + field `file`; API 명세가 다르면 `.env`의 `AISTREAM_REQUEST_MODE`, `AISTREAM_IMAGE_FIELD`를 바꾸세요. `json_base64`도 지원합니다. **모델 출력 포맷은 미확인**이므로 알 수 없는 값은 `unknown`으로 표시하고 절대로 조용히 정상으로 취급하지 않습니다. 이 경우 `/api/response/{id}` 또는 웹 콘솔에서 실제 응답을 확인하고 `app/aistream.py` 파서를 조정하세요.

### 한 번에 받아야 할 데이터

1. 대회 **에너지(A트랙) 풍력(Wind) RGB 원본 이미지**
2. 해당 이미지의 **정답 JSON**, 정상/결함 라벨이 명확한 샘플
3. 모델의 결함 클래스/정상 의미 및 실제 API `/docs`
4. 권장: 촬영 세션/장비/부위 정보(누수 방지와 분석용)
5. 선택: 결함 bbox, segmentation, severity(평가·시각화 단계에만 사용)

**외부 AIHub 원천 전체 자료를 별도 수집해서 대회에 추가하지 마세요.** 해커톤 제공 샘플을 사용해야 합니다. 태양광, VQA, 정비 비용/이력, 재배 기록은 이 MVP에 필요하지 않습니다.

## 대회 샘플 데이터 가져오기

방법 A: 웹에서 이미지 한 장을 직접 올린 뒤 AIStream 추론 → 정답이 없는 운영 화면 확인.

방법 B: `manifest.csv`가 들어 있는 ZIP을 웹에서 가져오기. 파일 구조 예시:

```
wind-test.zip
├── manifest.csv
└── images/
    ├── sample_001.jpg
    ├── sample_002.jpg
    └── sample_003.jpg
```

manifest.csv (필수 `image_file,truth`; 권장 `split,session,part`):

```csv
image_file,truth,split,session,part
images/sample_001.jpg,normal,train,session_A,BladeA
images/sample_002.jpg,defect,val,session_B,BladeA
images/sample_003.jpg,defect,test,session_C,BladeB
```

- `truth`는 **실제 정답 라벨**이고, 모델이 예측한 값이 아닙니다. `normal`/`defect`만 허용.
- `split=train|val|test|unassigned`; 평가(`/api/evaluate`)는 **test**만 사용합니다.
- 동일 촬영 세션·설비·원본 이미지 변형본은 같은 split으로 묶으세요. 이미지를 무작위로 나누면 누수가 발생할 수 있습니다.
- 실 샘플에 라벨 파일만 있을 경우 `python scripts/build_manifest.py --images <folder> --labels <folder> --out manifest.csv --zip wind_subset.zip --limit 100 --split unassigned`를 사용하세요. 실제 JSON에 `info.db_name`이 명확할 때만 정답으로 채웁니다. 미확인 레코드는 제외/보고합니다.
- ZIP 130MB 이하, 회당 300장 이하. 큰 자료는 테스트용 소규모 ZIP 여러 개로 나누세요.
- 업로드 후 API 추론에서 정상·미검출 후보가 나오는지 확인하세요.

## AI 오류 예측기 학습

`POST /api/train`은 실제 제공 모델이 `normal`로 판정한 **train split** 중, 정답이 `defect`인 항목 3개 이상과 `normal`인 항목 3개 이상을 포함하는 최소 12건이 있어야 학습됩니다. 학습 전에는 규칙 기반 우선순위만 적용합니다.

검증은 `test split`의 실제 정답에서만 수행합니다. `Capture@K`, `Precision@K`, `Remaining@K`를 **같은 입력 집합과 K**에서 무작위, 영상품질 규칙, (신뢰도 제공 시) 낮은 confidence 순과 비교합니다. 추가 학습 모델의 점수는 교정된 확률이 아니므로 `90% 고장 확률` 등으로 표현하지 마세요.

주의: 대회 제공 모델의 기존 학습 데이터와 사용자가 평가용으로 나눈 이미지가 중복되는지 별도 확인이 필요합니다. 이미 모델에 학습된 이미지를 시험에 사용한다면 미관측 현장 일반화 성능으로 발표할 수 없습니다.

## 데이터/성능 관련 주의

- 모델 응답에 confidence가 없으면 신뢰도 정렬 비교를 생략합니다.
- 실제 누락(모델 normal, 정답 defect)이 0개라면 Capture@K를 100%가 아닌 **평가 불가**로 표시합니다.
- JSON 라벨을 모델 추론 입력으로 사용하지 마세요. API에는 원본 이미지만 보냅니다.
- 원천 JSON의 `info.db_name=NormalDB/PositiveDB`는 **정답 식별 목적으로만** 쓸 수 있습니다. 정상·결함 판정은 실제 구조를 확인하고 결정해야 합니다.
- `annotations=[]`을 근거로 무조건 normal이라고 해석하지 않습니다.
- API 실패를 정상으로 저장하지 않습니다.
- 저장 모델(`data/ranker.joblib`)은 이 애플리케이션에서 직접 생성한 경우에만 로드하세요. 외부에서 받은 pickle/joblib은 위험합니다.
- 배포 공개 URL에는 기업 비밀 이미지, 개인정보, API 인증키 등을 노출하지 마세요.
- `.env`, `.pem`, `.key`, `data/` 전체가 Git에 포함되지 않게 `.gitignore`를 점검하세요. 이미 유출된 인증키는 재발급하세요.
- 발표에서 게임 느낌은 **문제 도입과 결과 공개 연출**로만 활용하고 실제 서비스 UI는 산업용으로 유지합니다.

## 테스트

```bash
pytest -q
```

실제 API와 데이터 없이 시연용 가짜 성능을 만들지 않도록, 기본 앱은 빈 상태로 시작합니다. `scripts/create_ui_fixture.py`는 테스트용 이미지와 "모의" 판정을 추가하지만, `origin=simulated`로 표시하며 실험 평가/학습 대상에서 자동 제외합니다. 대회 발표의 모델 성능 수치에 사용하지 마세요.

## 권장 발표 7분

0:00~0:45 “정상이라던 사진 안에 누락 결함이 있다면?” / 0:45~1:30 데이터·AIStream / 1:30~3:30 실제 추론+검수 K 설정 / 3:30~5:00 동일 K 성능 비교 / 5:00~6:15 현장 활용 / 6:15~7:00 한계와 최종 요약.
