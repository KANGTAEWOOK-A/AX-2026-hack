import io
import os
import csv
import zipfile
from PIL import Image

os.environ['WR_DATA_DIR'] = '/tmp/windrecheck_pytest_isolated'
from fastapi.testclient import TestClient
from app.main import app, db, MODEL, UPLOADS
from app.aistream import parse_response
from app.engine import evaluate, priority

client = TestClient(app)


def sample_jpg(color=(130, 130, 130)):
    f = io.BytesIO()
    Image.new('RGB',(80,80),color).save(f,'JPEG')
    return f.getvalue()


def test_parser_is_conservative(monkeypatch):
    monkeypatch.delenv('AISTREAM_EMPTY_IS_NORMAL', raising=False)
    assert parse_response({'detections': []})['pred'] == 'unknown'
    assert parse_response({'label':'normal','confidence':0.91})['pred'] == 'normal'
    assert parse_response({'is_defect':True})['pred'] == 'defect'
    assert parse_response({'result': {'prediction': 'defect', 'score':0.71}})['confidence'] == 0.71
    assert parse_response({'unexpected':{'prob':0.95}})['pred'] == 'unknown'


def test_upload_and_queue():
    response = client.post('/api/upload', files={'file':('wind.jpg',sample_jpg(),'image/jpeg')})
    assert response.status_code == 200, response.text
    ident = response.json()['id']
    assert client.get(f'/api/image/{ident}').status_code == 200
    assert client.get('/api/summary').json()['total'] > 0
    with db() as c:
        c.execute("UPDATE items SET pred='normal',confidence=0.9,api_state='success' WHERE id=?",(ident,))
    q=client.get('/api/queue?k=2').json()
    assert q['eligible'] >= 1
    assert any(row['id']==ident for row in q['items'])
    response=client.post('/api/review',json={'id':ident,'status':'completed','note':'checked'})
    assert response.status_code==200
    assert client.get('/api/summary').json()['reviewed']>=1
    assert client.get('/api/response/'+ident).json()['response'] is None


def test_manifest_zip_import_and_no_truth_in_operational_api():
    csvdata='image_file,truth,split,session,part\nimages/test.jpg,defect,test,group2,BladeA\n'
    stream=io.BytesIO()
    with zipfile.ZipFile(stream,'w') as f:
        f.writestr('manifest.csv',csvdata)
        f.writestr('images/test.jpg',sample_jpg())
    r=client.post('/api/import-zip',files={'file':('test.zip',stream.getvalue(),'application/zip')})
    assert r.status_code==200 and r.json()['imported']==1,r.text
    all_rows=client.get('/api/items').json()['items']
    assert all('truth' not in row for row in all_rows)


def test_evaluation_same_k_and_test_only():
    dataset=[]
    for i in range(10):
        dataset.append({'id':str(i),'split':'test' if i<8 else 'train','pred':'normal',
                        'truth':'defect' if i in (0,2,5,9) else 'normal',
                        'origin':'real','confidence':0.6+(i%4)*0.06,
                        'brightness':0.3+i*0.05,'contrast':0.3,'blur_log':2,
                        'dark_ratio':0,'bright_ratio':0})
    out=evaluate(dataset,3)
    assert out['test_count']==8 and out['missed_defect_count']==3
    assert all(x['selected']==3 for x in out['methods'])
    assert all(x['remaining']==3-x['found'] for x in out['methods'])
    assert any(x['method']=='낮은 신뢰도순' for x in out['methods'])
    for r in dataset: r['truth']='normal'
    zero=evaluate(dataset,3)
    assert zero['missed_defect_count']==0
    assert all(x['capture_at_k'] is None for x in zero['methods'])


def test_missing_url_never_simulates_real_api():
    from app.aistream import infer
    os.environ.pop('AISTREAM_WIND_URL',None)
    try:
        infer(sample_jpg(),'wind.jpg')
        assert False,'must fail'
    except ValueError as e:
        assert '미설정' in str(e)
